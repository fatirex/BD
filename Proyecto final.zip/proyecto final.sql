DROP DATABASE IF EXISTS proyecto_final;
CREATE DATABASE proyecto_final;
USE proyecto_final;

CREATE TABLE proveedor(
 codigo int primary key auto_increment,
 nombre varchar (20) not null,
 direccion varchar (20) not null,
 provincia  varchar (20) not null
);

CREATE TABLE categoria(
	codigo int primary key auto_increment,
	nombre varchar (20) not null
);

CREATE TABLE pieza(
	codigo int primary key auto_increment,
	color varchar(15) not null, 
	precio float not null,
	categoria_codigo int not null,
    constraint pieza_categoria_codigo_categoria_codigo_fk
	FOREIGN KEY (categoria_codigo) 
    references categoria(codigo)
);

CREATE TABLE suministra(
    fecha date ,
	cantidad int not null,
    proveedor_codigo int not null,
    constraint suministra_proveedor_codigo_proveedor_codigo_fk
    foreign key(proveedor_codigo)
    references proveedor(codigo),
    pieza_codigo int not null,
    primary key(fecha,proveedor_codigo,pieza_codigo),
    constraint suministra_pieza_codigo_pieza_codigo_fk
    foreign key(pieza_codigo)
    references pieza(codigo)
	);
    

